import React from 'react';
import MenuIcon from '@mui/icons-material/Menu';
import SearchIcon from '@mui/icons-material/Search';
import VideoCallIcon from '@mui/icons-material/VideoCall';
import AppsIcon from '@mui/icons-material/Apps';
import NotificationsIcon from '@mui/icons-material/Notifications';
import MicIcon from '@mui/icons-material/Mic'; // Microphone icon import
import ytLogo from './assets/ytlogo.webp'; // Import your logo

import './Header.css'

const Header = () => {
    return (
        <div className='header'>

            <div className='header_left'>
                <MenuIcon />
                <img className='header_logo' src={ytLogo} alt="YouTube Logo" />
            </div>{/* End of div with className = header_left  */}


            <div className='header_input'>
                <div className='header_middle'>
                    <input className='searchInput' placeholder='Search' type="text" />
                    <SearchIcon  className='header_searchBtn'/>
                </div>{/* End of div with className = header_middle  */}
                <MicIcon />
            </div>{/* End of div with className = header_input  */}


            <div className='header_right'>
                <VideoCallIcon />
                <AppsIcon  className='header_icons'/>
                <NotificationsIcon /> 
            </div>{/* End of div with className = header_right  */}

        </div> // End of div with className = Header  
    );
};

export default Header;
